import { useEffect, useState } from 'react';

export default function Education() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className={`transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Education</h2>
          
          {/* ESSEC */}
          <div className="mb-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">ESSEC</h3>
                <p className="text-gray-600 dark:text-gray-300">Exchange Program, Global BBA</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600 dark:text-gray-300">Paris, France</p>
                <p className="text-gray-600 dark:text-gray-300">Aug 2024 – Aug 2025</p>
              </div>
            </div>
            <p className="text-gray-700 dark:text-gray-300">
              <span className="font-semibold">Core Course:</span> Luxury Brand Management, Finance 1, Beginner French, Doing Business in China, European Economics
            </p>
          </div>

          {/* Bayes Business School */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Bayes Business School, City, University of London</h3>
                <p className="text-gray-600 dark:text-gray-300">BSc Business with Finance</p>
                <p className="text-gray-600 dark:text-gray-300">GPA: 3.3/4</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600 dark:text-gray-300">London, UK</p>
                <p className="text-gray-600 dark:text-gray-300">Sep 2022 - Jun 2026</p>
              </div>
            </div>
            <p className="text-gray-700 dark:text-gray-300">
              <span className="font-semibold">Core Courses:</span> Marketing, Management, Critical Analysis, Operation & Supply Chain Management, Economics, Financial & Management Accounting, Financial Market, Business Law
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}