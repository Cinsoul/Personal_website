import { useEffect, useState } from 'react';

export default function WorkExperience() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className={`transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Work Experience</h2>
          
          {/* Starbucks */}
          <div className="mb-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Starbucks (Part-time)</h3>
                <p className="text-gray-600 dark:text-gray-300">Barista</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600 dark:text-gray-300">London, UK</p>
                <p className="text-gray-600 dark:text-gray-300">Mar 2023 – Aug 2024</p>
              </div>
            </div>
            <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
              <li>Sales & Operations Support: Promote seasonal new products in the store according to customer needs, improve new product sales, and promote the store's overall revenue growth</li>
              <li>Marketing Skills: Successful promotion of seasonal beverage sales, with sales growth of 15%</li>
            </ul>
          </div>

          {/* UKpathway Consultancy Group */}
          <div className="mb-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">UKpathway Consultancy Group (Part-time)</h3>
                <p className="text-gray-600 dark:text-gray-300">Marketing Department</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600 dark:text-gray-300">Remote</p>
                <p className="text-gray-600 dark:text-gray-300">Dec 2022 – Feb 2023</p>
              </div>
            </div>
            <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
              <li>Promote Products: Introduce company services on social media</li>
              <li>Analyse Services: Analyse and highlight the advantages of services and compare them with other companies services</li>
            </ul>
          </div>

          {/* MUJI */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">MUJI (Part-time)</h3>
                <p className="text-gray-600 dark:text-gray-300">Sales Consultant</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600 dark:text-gray-300">Fuzhou, China</p>
                <p className="text-gray-600 dark:text-gray-300">Oct 2021 – Jun 2022</p>
              </div>
            </div>
            <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
              <li>Teamwork: Collaborate with the team on promotional activities to increase sales by 10% through effective communication and execution</li>
              <li>Personal Achievement: Assist in optimising inventory management processes and increase product turnover efficiency by 15%</li>
              <li>Insight: Learn how brands operate globally and understand how they differentiate themselves in their local markets</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}