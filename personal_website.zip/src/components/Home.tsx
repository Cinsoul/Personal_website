import { useEffect, useState } from 'react';
import profileImage from '../assets/business-avatar.svg';
import fallbackImage from '../assets/business-avatar.svg';

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className={`flex flex-col md:flex-row items-center justify-between gap-8 transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Xindi (Arthur) Wang</h1>
            <div className="text-xl text-gray-600 dark:text-gray-300 mb-4">
              <p className="mb-2">BSc Business with Finance Student</p>
              <p className="mb-2">Tel: +33 744839586</p>
              <p className="mb-2">Email: <a href="mailto:cinsoul9@gmail.com" className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-500">cinsoul9@gmail.com</a></p>
              <p>LinkedIn: <a href="https://linkedin.com/in/xindi-wang-18b10b24b" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-500">linkedin.com/in/xindi-wang-18b10b24b</a></p>
            </div>
            <div className="space-x-4">
              <a href="/education" className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">Education</a>
              <a href="/work" className="inline-block bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white px-6 py-3 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">Work Experience</a>
            </div>
          </div>
          <div className="flex-1 flex justify-center md:justify-end">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-300">
              <img 
                src={profileImage} 
                onError={(e) => {
                  console.warn('Profile image failed to load, falling back to SVG');
                  e.currentTarget.src = fallbackImage;
                  e.currentTarget.onerror = null;
                }}
                alt="Profile" 
                className="w-full h-full object-cover"
                loading="eager"
                decoding="async"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}