import { useState, useEffect } from 'react';

interface Certification {
  title: string;
  organization: string;
  date: string;
  credentialId: string;
  logo: string;
  link?: string;
}

export default function Certifications() {
  const [isLoaded, setIsLoaded] = useState(false);

  const certifications: Certification[] = [
    {
      title: 'LVMH Inside',
      organization: 'LVMH',
      date: 'Nov 2024',
      credentialId: '1d6c06f1be',
      logo: '/logos/lvmh.svg'
    },
    {
      title: 'Bloomberg Finance Fundamentals',
      organization: 'Bloomberg',
      date: 'Sep 2021',
      credentialId: 'YHrd8p8UahNuwGS6WU9LZfVM',
      logo: '/logos/bloomberg.svg'
    },
    {
      title: 'JPMorgan Chase - Investment Banking Job Simulation',
      organization: 'Forage',
      date: 'Apr 2021',
      credentialId: 'NEm3qnDfHC6fJi6fn',
      logo: '/logos/jpmorgan.svg'
    },
    {
      title: 'PwC - Career Plus',
      organization: 'PwC Mainland China and Hong Kong',
      date: 'Apr 2021',
      credentialId: '',
      logo: '/logos/pwc.svg'
    },
    {
      title: 'PwC US - Management Consulting Job Simulation',
      organization: 'Forage',
      date: 'Apr 2021',
      credentialId: 'SapWK5qhqAwbi2mCa',
      logo: '/logos/pwc.svg'
    },
    {
      title: 'The National Implementation of the Paris Agreement',
      organization: 'United Nations',
      date: 'Apr 2021',
      credentialId: 'r6T98YkY6Y',
      logo: '/logos/un.svg'
    },
    {
      title: '气候变化：从学习到行动',
      organization: 'United Nations',
      date: 'Apr 2021',
      credentialId: 'fTu5VttnpY',
      logo: '/logos/un.svg'
    }
  ];

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className={`transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Licenses & Certifications</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 mr-4 flex-shrink-0">
                      <img src={cert.logo} alt={cert.organization} className="w-full h-full object-contain" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{cert.title}</h3>
                      <p className="text-gray-600 dark:text-gray-300">{cert.organization}</p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    <p>Issued {cert.date}</p>
                    {cert.credentialId && (
                      <p className="mt-1">Credential ID: {cert.credentialId}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}