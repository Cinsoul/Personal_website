import { useState, useEffect } from 'react';

interface Project {
  title: string;
  description: string;
  technologies: string[];
  link?: string;
  image?: string;
}

interface Award {
  title: string;
  organization: string;
  date: string;
  description: string;
}

export default function ProjectsAndAwards() {
  const [isLoaded, setIsLoaded] = useState(false);

  const projects: Project[] = [
    {
      title: 'Personal Website',
      description: 'A responsive personal portfolio website built with React and Tailwind CSS, featuring dark mode support, responsive design, and smooth animations',
      technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
      link: 'https://github.com/yourusername/personal-website',
      image: '/project-images/personal-website.png'
    },
    {
      title: 'LVMH Digital Innovation',
      description: 'Developed innovative digital solutions for luxury retail, focusing on enhancing customer experience through AR/VR technology',
      technologies: ['React Native', 'AR Kit', 'Node.js', 'AWS'],
      image: '/logos/lvmh.svg'
    },
    {
      title: 'Bloomberg Market Analysis',
      description: 'Created a comprehensive market analysis tool using Bloomberg API, enabling real-time financial data visualization and analysis',
      technologies: ['Python', 'Bloomberg API', 'Pandas', 'Plotly'],
      image: '/logos/bloomberg.svg'
    },
    {
      title: 'Investment Banking Analytics',
      description: 'Developed financial models and analytics tools for investment banking operations, focusing on M&A analysis',
      technologies: ['Excel', 'VBA', 'Python', 'Financial Modeling'],
      image: '/logos/jpmorgan.svg'
    }
  ];

  const awards: Award[] = [
    {
      title: 'Dean\'s List',
      organization: 'Bayes Business School',
      date: '2023',
      description: 'Awarded for outstanding academic achievement and maintaining a high GPA throughout the academic year'
    },
    {
      title: 'LVMH Inside Program Completion',
      organization: 'LVMH',
      date: 'Nov 2024',
      description: 'Successfully completed the exclusive LVMH Inside program, gaining comprehensive insights into luxury retail and digital innovation'
    },
    {
      title: 'Bloomberg Market Concepts',
      organization: 'Bloomberg',
      date: 'Sep 2021',
      description: 'Completed advanced financial market analysis certification, covering economics, currencies, fixed income, and equities'
    },
    {
      title: 'Investment Banking Excellence',
      organization: 'JPMorgan Chase',
      date: 'Apr 2021',
      description: 'Recognized for outstanding performance in investment banking simulation program, focusing on M&A analysis and financial modeling'
    }
  ];

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className={`transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          {/* Projects Section */}
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project, index) => (
                <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                  {project.image && (
                    <div className="h-48 overflow-hidden">
                      <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">{project.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech, techIndex) => (
                        <span
                          key={techIndex}
                          className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                    {project.link && (
                      <a
                        href={project.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-500"
                      >
                        View Project →
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Awards Section */}
          <section>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Awards</h2>
            <div className="space-y-6">
              {awards.map((award, index) => (
                <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{award.title}</h3>
                      <p className="text-gray-600 dark:text-gray-300">{award.organization}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-gray-600 dark:text-gray-300">{award.date}</p>
                    </div>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300">{award.description}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}