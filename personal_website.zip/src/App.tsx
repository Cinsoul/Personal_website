import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import { FaBars, FaTimes } from 'react-icons/fa';
import ProjectsAndAwards from './components/ProjectsAndAwards';

import Home from './components/Home';
import Education from './components/Education';
import WorkExperience from './components/WorkExperience';
import SchoolExperience from './components/SchoolExperience';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <Router>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
        {/* Navigation */}
        <nav className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <a href="/" className="text-2xl font-bold text-gray-900 dark:text-white">Xindi (Arthur) Wang</a>
              </div>
              
              {/* Mobile menu button */}
              <div className="flex items-center md:hidden">
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300"
                >
                  {isMenuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
                </button>
              </div>

              {/* Desktop menu */}
              <div className="hidden md:flex md:items-center md:space-x-8">
                <a href="/" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Home</a>
                <a href="/education" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Education</a>
                <a href="/work" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Work Experience</a>
                <a href="/school" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">School Experience</a>
                <a href="/contact" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Contact</a>
                <a href="/projects" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Projects & Awards</a>
              </div>
            </div>

            {/* Mobile menu */}
            <div className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
              <div className="px-2 pt-2 pb-3 space-y-1">
                <a href="/" className="block px-3 py-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Home</a>
                <a href="/education" className="block px-3 py-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Education</a>
                <a href="/work" className="block px-3 py-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Work Experience</a>
                <a href="/school" className="block px-3 py-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">School Experience</a>
                <a href="/contact" className="block px-3 py-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Contact</a>
                <a href="/projects" className="block px-3 py-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">Projects & Awards</a>
              </div>
            </div>
          </div>
        </nav>

        {/* Main content */}
        <main className="pt-16 min-h-screen">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/education" element={<Education />} />
            <Route path="/work" element={<WorkExperience />} />
            <Route path="/school" element={<SchoolExperience />} />
            <Route path="/contact" element={<div className="p-8">Contact Page Content</div>} />
            <Route path="/projects" element={<ProjectsAndAwards />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App
